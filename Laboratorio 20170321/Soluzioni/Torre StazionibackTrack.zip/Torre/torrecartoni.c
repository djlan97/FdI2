#include <stdio.h>
#include <stdlib.h>

#define N 3
#define DOUBLE_MAX 1000000

// ESERCIZIO 3

typedef struct {
  int peso;
  int altezza;
  int limite;
} pacco;

typedef struct {
  int altezza;    // altezza soluzione
  int pacco[N];  // lista pacco
} torre;



int verifica(torre *sol, int fine, pacco *p, int i)
{
   int j,k, somma;


    //printf("\nVerifica  %d, %d\n", p[i].peso, p[i].limite);

    for(j=0;j<=fine;j++){
	   //printf("\n(%d): %d",j, sol->pacco[j]);
    }

	 somma = 0;
	 for(j=0;j<fine; j++){
	// 	for(k=j+1; k<=fine; k++){
	 		somma += p[sol->pacco[j]].peso;
	// 	}
	}
	 	if (p[i].limite < somma){
			//printf("\nVerifica errata\n");
	 		return 0;

			}

			//printf("\nVerifica corretta\n");
   return 1;

}


// p pacco attuale nella soluzione corrente
// dis = altezza attuale
// c = torre attuale
// b = miglior torre
void Constorre(int n, pacco *p, int s, double dist, torre *c, torre *b, int *UsoPacco)
{
  int i;
  int tmp,parziale=0;

  if(s == n) { // terminati i pacchi

    if(c->altezza>b->altezza) {
      b->altezza=c->altezza;  // copia piano attuale in b
      for(i=0;i<n;i++){
	     b->pacco[i] = c->pacco[i];
	  }
    }
    return;
  }

  for(i=0;i<n;i++) {
	if (UsoPacco[i] == 0 ){
    //printf("\nPasso (%d), provo il pacco %d ", s, i);
	//getchar();
		if (verifica(c, s, p, i) == 1) {
			// inserimento
            //printf("\nPasso (%d), inserisco il pacco %d ", s, i);
			c->pacco[s] = i;
			c->altezza += p[i].altezza;
			UsoPacco[i] = 1;
			Constorre(n, p, s+1, dist, c, b, UsoPacco);
			//togli pacco
 	        c->pacco[s] = -1;
			UsoPacco[i] = 0;
            //printf("\nPasso (%d), tolgo il pacco %d ", s, i);
			c->altezza -= p[i].altezza;
		}
		else{
			Constorre(n, p, n, dist, c, b, UsoPacco);
		}

	}

   }
}


void main()
{
	int i;
  torre corrente, best;
  int n = N;
  pacco elencopacchi[N];
  int   listaUso[N];


	for (i=0; i<N;i++){
		corrente.pacco[i] = -1;
		best.pacco[i] = -1;
		listaUso[i] = 0;
	}


		elencopacchi[0].peso = 10;
		elencopacchi[0].altezza = 20;
		elencopacchi[0].limite = 40;

		elencopacchi[1].peso = 10;
		elencopacchi[1].altezza = 10;
		elencopacchi[1].limite = 8;

		elencopacchi[2].peso = 9;
		elencopacchi[2].altezza = 3;
		elencopacchi[2].limite = 5;

    for(i=0;i<n;i++)

	   printf("\n(%d): %d,  %d",i, elencopacchi[i].peso, elencopacchi[i].limite);

  getchar();

  corrente.altezza=0;
  best.altezza=0;

  Constorre(n,elencopacchi,0,0,&corrente,&best, listaUso);

  if(best.altezza==0)
    printf("Impossibile costruire la torre");
  else {
    printf("\nElenco pacchi (dall'alto al basso): ");
    for(i=0;i<n;i++)
      if(best.pacco[i]>=0)
				printf("\n(%d): %d",i, best.pacco[i]);
  }

  getchar();
}

