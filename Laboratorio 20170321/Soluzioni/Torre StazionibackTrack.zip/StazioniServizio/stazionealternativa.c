#include <stdio.h>
#include <stdlib.h>

#define N 5
#define DOUBLE_MAX 1000000

typedef struct {
  double costo;    // costo soluzioni
  int stazione[N];  // lista fermate
} piano;



void pianifica(double M, int n, double *d, double *p, int s, double dist, piano c, piano *b, double PercorsoDaUltimoRifornimento)
{
 int i;

  if(dist+600-PercorsoDaUltimoRifornimento >= M) {//600km e' la distanza percorribile con un pieno
    printf("\nTrovata soluzione (%f), (percorsi %f km)\n",c.costo, dist);
      for(i=0;i<n;i++)
		 printf("%d ",c.stazione[i]);
	//getchar();
    if(c.costo<b->costo) {
      b->costo=c.costo;  // copia piano attuale in b
      //printf("Trovato best (%f)",b->costo);
      for(i=0;i<n;i++){
	     b->stazione[i] = c.stazione[i];
		 //printf("\n%d",b->stazione[i]);
      }
	}
    return;
  }

	dist+=d[s];
	PercorsoDaUltimoRifornimento+=d[s];
	if (PercorsoDaUltimoRifornimento + d[s+1] < 600){
		c.stazione[s]=0;
        //printf("\nSalto Rifornimento in stazione %d, (percorsi %f km)", i, dist);
		pianifica(M,n,d,p,s+1,dist,c,b,PercorsoDaUltimoRifornimento);
		}

    if (PercorsoDaUltimoRifornimento < 600){
		c.costo += PercorsoDaUltimoRifornimento * 0.05 * p[s]; // aggiungo costo di rifornirmi in i
        c.stazione[s]=1;
		PercorsoDaUltimoRifornimento=0;
		//printf("\nRifornimento in stazione %d, (percorsi %f km)", i, dist);
		pianifica(M,n,d,p,s+1,dist,c,b,PercorsoDaUltimoRifornimento);
	}
}



void main()
{
	double M = 0;
	int i;
  piano corrente, best;
  int n = N;
  double distanza[N], prezzo[N];

	for (i=0; i<N;i++){
		corrente.stazione[i] = 0;
		best.stazione[i] = 0;
		prezzo[i] = i + 35 - i*i ;
		distanza[i] = 260 + i * 24;
		M+=distanza[i];
		printf("\nstazione %d,  km %f, prezzo %f",i, distanza[i], prezzo[i]);
	}

  corrente.costo=0;
  best.costo=DOUBLE_MAX;

  printf("\nInizio la pianificazione (percorso %f)", M);
  getchar();

  pianifica(M,n,distanza,prezzo,0,0,corrente,&best,0);

  if(best.costo==DOUBLE_MAX)
    printf("\nImpossibile raggiungere la meta");
  else {
    printf("\nConviene fare il pieno nelle stazioni: ");
    for(i=0;i<n;i++)
      if(best.stazione[i]==1)
				printf("\n%d",i);
	printf("\nCosto totale: %f ", best.costo);
  }
}


