#include <stdio.h>
#include <stdlib.h>

#define N 5
#define DOUBLE_MAX 1000000

// ESERCIZIO 3
typedef struct {
  double costo;    // costo soluzioni
  int stazione[N];  // lista fermate
} piano;



// s stazione corrente
// dist = distanza percorsa
// c = piano attuale
// b = miglior piano
void pianifica(double M, int n, double *d, double *p, int s, double dist, piano *c, piano *b)
{
  int i;
  double tmp,parziale=0;

  if(dist+600>= M) {//600km e' la distanza percorribile con un pieno

    if(c->costo<b->costo) {
      b->costo=c->costo;  // copia piano attuale in b
      for(i=0;i<n;i++)
	     b->stazione[i] = c->stazione[i];
    }
    return;
  }

  tmp = c->costo;             // salva costo attuale
  for(i=s+1;i<n;i++) {
    parziale += d[i];
    if(parziale<600){ // con la benzina a disposizione posso arrivare fino alla stazione i
       c->stazione[i]=1;
       c->costo += parziale*0.05*p[i]; // aggiungo costo di rifornirmi in i

       pianifica(M,n,d,p,i,dist+parziale,c,b);

	   c->costo = tmp;           // ristabilisce vecchio c
       c->stazione[i]=0;
	   }
  }

}


void main()
{
	double M = 0;
	int i;
  piano corrente, best;
  int n = N;
  double distanza[N], prezzo[N];

	for (i=0; i<N;i++){
		corrente.stazione[i] = 0;
		best.stazione[i] = 0;
		prezzo[i] = i + 35 - i*i ;
		distanza[i] = 260 + i * 24;
		M+=distanza[i];
		printf("\nstazione %d,  km %f, prezzo %f",i, distanza[i], prezzo[i]);
	}

  corrente.costo=0;
  best.costo=DOUBLE_MAX;

  pianifica(M,n,distanza,prezzo,-1,0,&corrente,&best);

  if(best.costo==DOUBLE_MAX)
    printf("Impossibile raggiungere la meta");
  else {
    printf("\nConviene fare il pieno nelle stazioni (spesa totale %f): ", best.costo);
    for(i=0;i<n;i++)
      if(best.stazione[i]==1)
				printf("\n%d",i);
  }
}

